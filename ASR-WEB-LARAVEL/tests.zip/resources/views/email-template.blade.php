Subject: Permintaan Bantuan dari Website <br> <br>

Halo Tim Support,<br><br>

Anda menerima pesan baru dari pengunjung website. Berikut detail pesan yang dikirim: <br><br>

Nama: {{ $fromName }} <br>
Email: {{ $fromEmail }} <br>
Pesan: {{ $body }} <br><br>

Harap segera menindaklanjuti permintaan bantuan ini. <br><br>

Terima kasih,<br>
Tim Support

