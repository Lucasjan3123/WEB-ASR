

<?php $__env->startSection('subtitle'); ?>
Blog / Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content title'); ?>
Edit Blog
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

   
   <div class="container">
    <div class="card">
      <br><br>
      <form action="/AdminArea/blog/<?php echo e($blog->id); ?>" class="row g-3"method="POST" enctype="multipart/form-data" style="margin-left: 50px; margin-right:50px;" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <input type="text" hidden  name="users_id" value="<?php echo e(Auth::user()->id); ?>">

        <div class="col-md-6">
          <label  class="form-label">Author</label>
          <input type="text"  name="nama" readonly class="form-control" value="<?php echo e($blog->nama); ?>" >
          <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger">
              <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
          <label  class="form-label">Date</label>
          <input type="text" class="form-control"  readonly name="date" value="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>">
          <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger">
              <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-12">
          <label  class="form-label">Title</label>
          <input type="text" class="form-control"name="title"  value="<?php echo e($blog->title); ?>">
          <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger">
              <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-12">
          <label class="form-label">Kategori</label>
          <select name="_kategori_id" class="form-select" id="" >
            <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($item->id); ?>"<?php echo e($item->id == $blog->_kategori_id ? 'selected' : ''); ?>><?php echo e($item ->nama); ?></option>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option value="">Tidak ada kategori lain </option>
            <?php endif; ?>
    
          </select>
          <?php $__errorArgs = ['_kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger">
              <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
        </div>
        <div class="col-md-4">
          <label  class="form-label">Tag1</label>
          <input type="text" class="form-control" name="tag1" value="<?php echo e($blog->tag1); ?>">
          <?php $__errorArgs = ['tag1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger">
              <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
        </div>
        <div class="col-md-4">
          <label  class="form-label">Tag2</label>
          <input type="text" class="form-control" name="tag2" value="<?php echo e($blog->tag2); ?>" >
          <?php $__errorArgs = ['tag2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger">
              <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
        </div>
        <div class="col-md-4">
          <label  class="form-label">Tag3</label>
          <input type="text" class="form-control" name="tag3" value="<?php echo e($blog->tag3); ?>">
          <?php $__errorArgs = ['tag3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger">
              <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
        </div>

        
        <div class="col-12">
          <div class="form-group">
            <label for="photo">foto</label> <br>
            <?php if($blog->gambar): ?>
                <img src="<?php echo e(asset('image/' . $blog->gambar)); ?>" width="200px">
                <br><br>
            <?php endif; ?>
            <div class="input-group">
                <input type="text" name="gambars" class="form-control" id="photo" value="<?php echo e($blog->gambar); ?>" readonly>
                <div class="input-group-append">
                    <button type="button" class="btn btn-outline-secondary" onclick="document.getElementById('new_photo').click()">Browse</button>
                </div>
            </div>
            
            <small class="form-text text-muted">Leave it empty if you don't want to change the photo.</small>
            <input type="file" name="gambar" id="new_photo" style="display: none;">
            <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        </div>
        
        

        <div class="col-12">
          <label for="" class="form-label" > Content</label>
          <textarea name="content" id=""  class="form-control" cols="30" rows="10" ><?php echo e($blog->content); ?></textarea>
          <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger">
              <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <br><br><br>
        &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
        &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
        &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
        &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
        &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
        &ensp;&ensp;
        <div class="col-12">
          <button type="submit" class="btn btn-primary">Submit</button>
          <a type="button" href="/AdminArea/blog" class="btn btn-primary">back</a>

        </div>
        <br><br><br>
      </form>
      
    </div>
  </div>
  
  <script>
    document.getElementById('new_photo').addEventListener('change', function() {
        var photoInput = document.getElementById('photo');
        photoInput.value = this.value.split('\\').pop();
    });
</script>

    <?php if($errors->any()): ?>
   <div class="alert alert-danger">
     <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
 </div>
<?php endif; ?>








  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdmin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\New folder (4)\example-app\resources\views/HalamanAdminArea/EditBlog.blade.php ENDPATH**/ ?>