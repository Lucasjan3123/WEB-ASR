

<?php $__env->startSection('content'); ?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">  
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Blog - Presento Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  
<!-- Favicons -->
<link href="<?php echo e(asset("assets/img/favicon.png")); ?>" rel="icon">
<link href="<?php echo e(asset("assets/img/apple-touch-icon.png")); ?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset("assets/vendor/aos/aos.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("assets/vendor/bootstrap/css/bootstrap.min.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("assets/vendor/bootstrap-icons/bootstrap-icons.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("assets/vendor/boxicons/css/boxicons.min.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("assets/vendor/glightbox/css/glightbox.min.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("assets/vendor/remixicon/remixicon.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("assets/vendor/swiper/swiper-bundle.min.css")); ?>" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="<?php echo e(asset("assets/css/style.css")); ?>" rel="stylesheet">
  

</head>

<body>

  <style>
    .navbar-1-2.navbar-light .navbar-nav .nav-link {
      color: #092a33;
      transition: 0.3s;
    }
  
    .navbar-1-2.navbar-light .navbar-nav .nav-link.active {
      font-weight: 500;
    }
  
    .navbar-1-2 .btn-get-started {
      border-radius: 20px;
      font-weight: 500;
    }
  
    .navbar-1-2 .btn-get-started-yellow {
      background-color: #ffdda9;
      color: #372642;
      transition: 0.3s;
    }
  
    .navbar-1-2 .btn-get-started-yellow:hover {
      background-color: #fcd396;
      color: #372642;
      transition: 0.3s;
    }
  
    /* Media Query for screens with maximum width 900px */
    @media (max-width: 900px) {
      .navbar-1-2 .navbar-nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 100%;
      }
  
      .navbar-1-2 .navbar-nav .nav-item {
        margin-right: 10px;
      }
  
      .navbar-1-2 .navbar-nav .nav-link {
        padding: 5px 10px;
      }
  
      .navbar-1-2 .navbar-form {
        margin-top: 10px;
      }
    }
  
    /* Style untuk search bar */
    .search-container {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      margin-top: 10px;
    }
  
    .search-input {
      width: 200px;
      height: 43px;
      padding: 5px;
      border: none;
      border-radius: 3px;
      font-size: 14px;
    }
  
    .search-button {
      margin-left: 5px;
      padding: 5px 10px;
      margin-bottom: 20px;
      background-color: #fcd396;
      border: none;
      border-radius: 3px;
      font-size: 18px;
      cursor: pointer;
    }
  </style>
  
  <nav class="navbar-1-2 navbar navbar-expand-lg navbar-light p-4 px-md-4 mb-3 bg-body-tertiary"
    style="font-family: Poppins, sans-serif">
    <div class="container">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link px-md-4 active" aria-current="page" href="/News&Event/News&Event">All</a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-md-4" href="/News&Event/Event&Activities">Event & Activities</a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-md-4" href="/News&Event/blog">Blog</a>
        </li>
      </ul>
      <div class="search-container">
        <input type="text" class="search-input" placeholder="Search...">
        <button class="search-button">Search</button>
      </div>
    </div>
  </nav>
  
  
  
  
  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs" style="background-color: lightslategray">
      <div class="container">

        <ol>
          <li><a href="index.html" style="color: white" >Home</a></li>
          <li style="color: white">Blog</li>
        </ol>
        <h2>Blog</h2>

      </div>
    </div><!-- End Breadcrumbs -->

    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">
        
        <div class="row">

          <div class="col-lg-8 entries" style="font-family:calibri; font-size: 25px;">
            
            <hr> 
            <?php $__empty_1 = true; $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article>
              <div class="row">
              <div class="large-6 columns col-6">
                  <p ><img src="<?php echo e(asset('image/' .$item ->gambar)); ?> "alt="image for article" alt="article preview image"></p>
              </div>
              <div class="large-6 columns col-6">
                  <h3><a href="#" style="color: black">'<?php echo e($item->title); ?></a></h3>
                  <p>
                  <span><i class="bi bi-person-fill"> By <?php echo e($item->nama); ?> &nbsp;&nbsp;</i></span>
                  <span><i class="bi bi-calendar3"> <?php echo e($item->created_at->format('d F Y')); ?> &nbsp;&nbsp;</i></span>
                  
                  </p>
                  <p  ><?php echo e(Str::limit($item->content, 100)); ?></p><br>
                  <a href="/News&Event/ShowBlog/<?php echo e($item->slug); ?>" class="btn btn-primary" style="justify-content:center; margin-left:250px;" >Learn more</a>
      
              </div>
              
              </div>
          
          
              
              <hr>
      
              <br>
              
      
      
          </article>      
    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
            <?php endif; ?>

            
            
            
            

            <div class="blog-pagination">
              <ul class="justify-content-center">
            
                <!-- tombol "previous" -->
                <?php if($blogs->onFirstPage()): ?>
                  <li class="disabled"><a href="#"><span>&laquo;</span></a></li>
                <?php else: ?>
                  <li><a href="<?php echo e($blogs->previousPageUrl()); ?>" rel="prev"><span>&laquo;</span></a></li>
                <?php endif; ?>
            
                <!-- tautan navigasi halaman -->
                <?php $__currentLoopData = $blogs->getUrlRange(1, $blogs->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($page == $blogs->currentPage()): ?>
                    <li class="active"><a href="#"><?php echo e($page); ?></a></li>
                  <?php else: ?>
                    <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                <!-- tombol "next" -->
                <?php if($blogs->hasMorePages()): ?>
                  <li><a href="<?php echo e($blogs->nextPageUrl()); ?>" rel="next"><span>&raquo;</span></a></li>
                <?php else: ?>
                  <li class="disabled"><a href="#"><span>&raquo;</span></a></li>
                <?php endif; ?>
            
              </ul>
            </div>
            
          </div> <!-- End blog entries list -->

          <div class="col-lg-4">

            <div class="sidebar">

              <h3 class="sidebar-title">Search</h3>
              <div class="sidebar-item search-form">
                <form action="">
                  <input type="text" name="keyword">
                  <button type="submit"><i class="bi bi-search"></i></button>
                </form>
              </div><!-- End sidebar search formn-->

              <h3 class="sidebar-title">Categories</h3>
              <div class="sidebar-item categories">
                <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
                <ul>
                  <li><a href="<?php echo e(route('blog.filter', $item->id)); ?>"><?php echo e($item->nama); ?> </a></li>
                
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h3>no other category</h3>
                    
                <?php endif; ?>
              </div><!-- End sidebar categories-->

              <div class="container">
                <h3 class="sidebar-title">Archive Blog</h3>
        
                <?php $__currentLoopData = $archives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $blogArchives): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <h5 class="sidebar-title"><?php echo e($month); ?></h5>
                <?php $__currentLoopData = $blogArchives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="sidebar-item recent-posts">
                  <div class="post-item clearfix">
                    <img src="<?php echo e(asset('image/' .$blog ->gambar)); ?>" alt="">
                    <h4><a href="/News&Event/ShowBlog/<?php echo e($blog->id); ?>"><?php echo e($blog->title); ?></a></h4>
                    <time ><?php echo e($blog->created_at->format('d F Y')); ?></time>
                  </div> <br>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        

              <h3 class="sidebar-title">Tags</h3>
              <div class="sidebar-item tags">
                <ul>
                  <?php $__empty_1 = true; $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  
                  <li><a href="#"><?php echo e($item->name); ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      
                  <?php endif; ?>
                  
                </ul>
              </div><!-- End sidebar tags-->

            </div><!-- End sidebar -->

          </div><!-- End blog sidebar -->

        </div>

      </div>
    </section><!-- End Blog Section -->

  </main><!-- End #main -->


  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <script src="<?php echo e(asset("assets/vendor/purecounter/purecounter_vanilla.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/vendor/aos/aos.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/vendor/bootstrap/js/bootstrap.bundle.min.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/vendor/glightbox/js/glightbox.min.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/vendor/isotope-layout/isotope.pkgd.min.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/vendor/swiper/swiper-bundle.min.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/vendor/php-email-form/validate.js")); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset("assets/js/main.js")); ?>"></script>

</body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\New folder (4)\example-app\resources\views/Halaman News&Event/blog.blade.php ENDPATH**/ ?>