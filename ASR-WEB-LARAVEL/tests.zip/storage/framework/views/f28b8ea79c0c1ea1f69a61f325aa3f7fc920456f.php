


<?php $__env->startSection("subtitle"); ?>
Category & Tag
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content title'); ?>
Category & Tag
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="container text-center">

  <h1>  Category</h1>
    <!-- Button trigger modal -->
    <button style="float:right" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Create Category
      </button>
      
      <!-- Modal -->
      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/AdminArea/kategori" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Name Category</label>
                        <input type="text" class="form-control" name="nama" id="exampleFormControlInput1" >
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                      </div>
                      
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
          </div>
        </div>
      </div>

      <br><br><br><br><br><br>
        
      
      <div class="row">

        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4">
          <div class="card">
              <div class="card-body">
                <i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
                
                <span style="margin-left: 10px"><?php echo e($item->nama); ?></span>
                
  
                <a  href="" style="margin-left:40px" class="uk-icon-button" uk-icon="pencil" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($item->id); ?>">
                </a>
                  
                  <!-- Modal -->
                  <div class="modal fade" id="editModal<?php echo e($item->id); ?>" aria-hidden="true" aria-labelledby="editModal<?php echo e($item->id); ?>" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h1 class="modal-title fs-5" id="editModal<?php echo e($item->id); ?>">Modal title</h1>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form action="<?php echo e(route('kategori.updated', $item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="modal-body">
                                <h3>Edit Category</h3> <br>
                                <div class="mb-3">
                                    <label for="exampleFormControlInput1" class="form-label"> Name Category</label>
                                    <input type="text" class="form-control" name="nama" id="exampleFormControlInput1" >
                                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                                  </div>
                                  
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Save changes</button>
                            </div>
                        </form>
                      </div>
                    </div>
                  </div>
  
                  <a  href="#" class="uk-icon-button" uk-icon="close" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($item->id); ?>">
                  </a>
                  
                  <!-- Modal -->
                  <div class="modal fade" id="deleteModal<?php echo e($item->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"   aria-labelledby="deleteModal<?php echo e($item->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h1 class="modal-title fs-5" id="deleteModal<?php echo e($item->id); ?>">Modal title</h1>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form action="<?php echo e(route('kategori.delete', $item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <h4> Confirm deletion ?</h4>
                                
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Hapus</button>
                            </div>
                        </form>
                      </div>
                    </div>
                  </div>
                
  
              </div>
            </div>
        </div>
        
      
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      </div>

      <div style="border-top:  2px solid black" >

        <br><br><br>
          <h1>Tag</h1>
                   <!-- Button trigger modal -->
        <button style="float:right" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModalTag">
          Create Tag
        </button>
        
        <!-- Modal -->
        <div class="modal fade" id="exampleModalTag" tabindex="-1" aria-labelledby="exampleModalLabel1" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel1">Modal title</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <form action="/AdminArea/tag" method="POST">
                  <?php echo csrf_field(); ?>
                  <div class="modal-body">
                      <div class="mb-3">
                          <label for="exampleFormControlInput2" class="form-label">Name tag</label>
                          <input type="text" class="form-control" name="name" id="exampleFormControlInput2" >
                          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  
                        </div>
                        
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                  </div>
              </form>
            </div>
          </div>
        </div>
    
        <br><br><br><br><br><br>
          
        
        <div class="row">
    
          <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-4">
            <div class="card">
                <div class="card-body">
                  <i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
                  
                  <span style="margin-left: 10px"><?php echo e($item->name); ?></span>
                  
    
                  <a  href="" style="margin-left:40px" class="uk-icon-button" uk-icon="pencil" data-bs-toggle="modal" data-bs-target="#edittagModal<?php echo e($item->id); ?>">
                  </a>
                    
                    <!-- Modal -->
                    <div class="modal fade" id="edittagModal<?php echo e($item->id); ?>" aria-hidden="true" aria-labelledby="edittagModal<?php echo e($item->id); ?>" tabindex="-1">
                      <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h1 class="modal-title fs-5" id="edittagModal<?php echo e($item->id); ?>">Modal title</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="<?php echo e(route('tag.updated', $item->id)); ?>" method="POST">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('put'); ?>
                              <div class="modal-body">
                                  <h3>Edit Tag</h3> <br>
                                  <div class="mb-3">
                                      <label for="exampleFormControlInput1" class="form-label"> Name Tag</label>
                                      <input type="text" class="form-control" name="name" id="exampleFormControlInput1" >
                                      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="alert alert-danger">
                                          <?php echo e($message); ?>

                                      </div>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              
                                    </div>
                                    
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save changes</button>
                              </div>
                          </form>
                        </div>
                      </div>
                    </div>
    
                    <a  href="#" class="uk-icon-button" uk-icon="close" data-bs-toggle="modal" data-bs-target="#deletetagModal<?php echo e($item->id); ?>">
                    </a>
                    
                    <!-- Modal -->
                    <div class="modal fade" id="deletetagModal<?php echo e($item->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"   aria-labelledby="deletetagModal<?php echo e($item->id); ?>" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h1 class="modal-title fs-5" id="deletetagModal<?php echo e($item->id); ?>">Modal title</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="<?php echo e(route('tag.delete', $item->id)); ?>" method="POST">
                              <?php echo csrf_field(); ?>
                              <div class="modal-body">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('delete'); ?>
                                  <h4> Confirm deletion ?</h4>
                                  
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Hapus</button>
                              </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  
    
                </div>
              </div>
          </div>
          
        
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </div>
      </div>
      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
   <?php endif; ?>

      
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdmin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\New folder (4)\example-app\resources\views/HalamanAdminArea/kategori.blade.php ENDPATH**/ ?>