

<?php $__env->startSection('subtitle'); ?>
News
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content title'); ?>
News
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<style>
  ul#text {
    padding: 0;
}

ul#text li {
    display: inline;
}

ul#text li a {
    /* background-color: green; */
    /* color: white; */
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 4px 4px 0 0;
}

</style>
<div class="container">
    <div class="text-end upgrade-btn" style="float: right">
        <a href='/AdminArea/news/create' class="btn btn-primary text-white"
            target="_blank">Create</a>
    </div>

  </div>
  <br><br><br><br>
  <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="container">

  
  
  <div class="container-fluid">
    <div class="row">
      <div class="col-6">
      
        <div class="card" style="width: 35rem;">
          <img src="<?php echo e(asset('image/' .$item ->gambar)); ?>" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><?php echo e($item->title); ?></h5>
              <ul id="text">
                <li>
                  
                  <i class="bi bi-person"></i> <a href="blog-single.html"><?php echo e($item->Author); ?></a>
                </li>
                <li>
    
                  <i class="bi bi-clock"></i> <a href="blog-single.html"><?php echo e($item->Date); ?></a>
                </li>
                <li>
    
                  
                </li>
              </ul>
            <p class="card-text" contenteditable="true"  style="overflow: hidden; white-space: nowrap; text-overflow: ellipsis;" ><?php echo e($item->Content); ?></p> <br>
            <a href="/AdminArea/news/<?php echo e($item->id); ?>" class="btn btn-primary" style="float: right">Read More</a>
          </div>
          <div class="d-flex border-top">
            <small class="w-50 text-center border-end py-2">
                 <a  href='/AdminArea/news/<?php echo e($item->id); ?>/edit'class="btn btn-outline-warning border-2" >Edit </a>
            </small>
            <small class="w-50 text-center py-2">
                <form action="/AdminArea/news/<?php echo e($item->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                  <input type="submit" value="Delete " class="btn btn-outline-danger border-2 " > 
                    </form>
            </small>
        </div>
        </div>
      
      </div>
    </div>
  </div>
</div>
  
  
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    
<?php endif; ?>


  </article><!-- End blog entry -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdmin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\New folder (4)\example-app\resources\views/HalamanAdminArea/news.blade.php ENDPATH**/ ?>