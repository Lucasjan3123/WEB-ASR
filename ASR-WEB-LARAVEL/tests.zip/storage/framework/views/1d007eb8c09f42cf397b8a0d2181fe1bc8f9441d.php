

<?php $__env->startSection('subtitle'); ?>
News / Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content title'); ?>
Create News
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    
  <div class="container">
    <div class="card">
      <br><br>

      <form method="POST" action="/AdminArea/news" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
    
        <input type="text" hidden  name="users_id" value="<?php echo e(Auth::user()->id); ?>">

        <div class="col-md-6">
          <label  class="form-label">Author</label>
          <input type="text"  readonly name="Author" class="form-control" value="<?php echo e(Auth::user()->name); ?>" >
        </div>
        <div class="col-md-6">
          <label  class="form-label">Date</label>
          <input type="text" class="form-control"  readonly name="Date" value="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>">
        </div>
        <div class="col-12">
          <label  class="form-label">Title</label>
          <input type="text" class="form-control"name="Title">
        </div>
        <div class="col-md-4">
          <label  class="form-label">Tag1</label>
          <input type="text" class="form-control" name="tag1">
        </div>
        <div class="col-md-4">
          <label  class="form-label">Tag2</label>
          <input type="text" class="form-control" name="tag2">
            
        </div>
        <div class="col-md-4">
          <label  class="form-label">Tag3</label>
          <input type="text" class="form-control" name="tag3">
        </div> <br><br>
        <div class="col-12">
          <div>
            <label for="gambar">Gambar Utama</label>
            <input type="file" id="gambar" name="gambar" accept="image/jpeg,image/jpg,image/png" required>
        </div>
    
        <?php for ($i = 1; $i <= 8; $i++) : ?>
            <div>
                <label for="gambar<?= $i ?>">Gambar Tambahan <?= $i ?></label>
                <input type="file" id="gambar<?= $i ?>" name="gambar<?= $i ?>" accept="image/jpeg,image/jpg,image/png">
            </div>
        <?php endfor; ?>

        </div>
        
        

      


        <div class="col-12">
          <label for="" class="form-label" > Content</label>
          <textarea name="Content" id=""  class="form-control" cols="30" rows="10"></textarea>
        </div>

        
        <br><br><br>
        &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
        &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
        &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
        &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
        &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
        &ensp;&ensp;
        <div class="col-12">
          <button type="submit" class="btn btn-primary">Submit</button>
          <a type="button" href="/AdminArea/blog" class="btn btn-primary">back</a>
        </div>
      </form>
      <br><br><br>
    </div>
  </div>
  
 

    <?php if($errors->any()): ?>
   <div class="alert alert-danger">
     <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
 </div>
<?php endif; ?>


<script>
  function toggleImageInput() {
  var container = document.getElementById("image-input-container");
  var inputCount = container.getElementsByTagName("input").length;

  if (inputCount < 8) {
    var label = document.createElement("label");
    label.innerHTML = "File Input Gambar";
    label.setAttribute("class", "form-label");

    var input = document.createElement("input");
    input.setAttribute("type", "file");
    input.setAttribute("class", "form-control");
    input.setAttribute("name", "gambar[]");

    var lineBreak = document.createElement("br");

    container.appendChild(label);
    container.appendChild(input);
    container.appendChild(lineBreak);
  }
}

</script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdmin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\New folder (4)\example-app\resources\views/HalamanAdminArea/CreateNews.blade.php ENDPATH**/ ?>